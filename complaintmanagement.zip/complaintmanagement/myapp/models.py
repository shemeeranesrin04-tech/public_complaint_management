from django.contrib.auth.models import User
from django.db import models

# Create your models here.
class Department(models.Model):
    AUTH_USER=models.ForeignKey(User,on_delete=models.CASCADE)
    dname=models.CharField(max_length=100)
    description=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
class Registration(models.Model):
    AUTH_USER=models.ForeignKey(User,on_delete=models.CASCADE)
    name=models.CharField(max_length=100)
    gender = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    phone= models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    pincode = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    image = models.ImageField()

class Complaint(models.Model):
    REGISTRATION=models.ForeignKey(Registration,on_delete=models.CASCADE)
    DEPARTMENT = models.ForeignKey(Department, on_delete=models.CASCADE)
    date = models.CharField(max_length=100)
    complaint = models.CharField(max_length=100)
    category = models.CharField(max_length=100)
    priority = models.CharField(max_length=100)
    status = models.CharField(max_length=100)
    place_name = models.CharField(max_length=100)
    image = models.ImageField()
    latitude = models.CharField(max_length=100)
    longitude = models.CharField(max_length=100)


class Action(models.Model):
    COMPLAINT=models.ForeignKey(Complaint,on_delete=models.CASCADE)
    date=models.CharField(max_length=100)
    description=models.CharField(max_length=100)

class Appreview(models.Model):
    REGISTRATION = models.ForeignKey(Registration, on_delete=models.CASCADE)
    review=models.CharField(max_length=100)
    rating=models.CharField(max_length=100)
    date=models.CharField(max_length=100)

