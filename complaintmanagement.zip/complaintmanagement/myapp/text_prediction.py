


import google.generativeai as genai
import json
import re
from PIL import Image

# Configure Gemini
genai.configure(api_key="AIzaSyB9w_Ow_JnZm17_lMj7XmOE00A8Bbuxhrw")

# Department & Priority lists
DEPARTMENT_LIST = [
    "Water Authority", "KSEB", "PWD", "Traffic Police", "LSGD",
    "Pollution Control Board", "Forest Department"
]
PRIORITY_LIST = ["Low", "Medium", "High"]


def load_image(image_path):
    """Load image safely."""
    try:
        return Image.open(image_path)
    except Exception:
        return None


def describe_image(image):
    """Generate short description of an image using Gemini."""
    try:
        model_gemini = genai.GenerativeModel('gemini-2.5-flash')
        prompt = "Describe the scene in this image in 1-2 sentences. Focus only on visible damages, hazards, or public issues."
        response = model_gemini.generate_content([prompt, image])
        return response.text.strip()
    except Exception:
        return None


def full_prediction(complaint_text, complaint_image_path=None):
    """Predict department & priority with Gemini AI."""
    image_desc = None
    if complaint_image_path:
        image = load_image(complaint_image_path)
        if image:
            image_desc = describe_image(image)

    combined_context = f'COMPLAINT: "{complaint_text}"'
    if image_desc:
        combined_context += f' IMAGE CONTEXT: "{image_desc}"'

    prompt_template = f"""
    Analyze the following:
    {combined_context}

    Classify the complaint:
    1. Department → one of {DEPARTMENT_LIST}
    2. Priority → one of {PRIORITY_LIST}

    Respond ONLY in JSON:
    {{"department": "...", "priority": "..."}}
    """

    predicted_department = "Unknown"
    priority = "Low"

    try:
        model_gemini = genai.GenerativeModel('gemini-2.5-flash')
        response = model_gemini.generate_content(prompt_template)

        match = re.search(r'\{.*\}', response.text.strip(), re.DOTALL)
        if match:
            data = json.loads(match.group(0))
            predicted_department = data.get("department", "Unknown")
            priority = data.get("priority", "Low")

            if predicted_department not in DEPARTMENT_LIST:
                predicted_department = "Unknown"
            if priority not in PRIORITY_LIST:
                priority = "Low"
    except Exception as e:
        print(f"Prediction error: {e}")

    return {
        "complaint_text": complaint_text,
        "image_description": image_desc,
        "predicted_department": predicted_department,
        "priority": priority
    }
