import joblib
import tensorflow as tf
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.models import load_model
import cv2
import numpy as np

# Load pre-trained LSTM for text classification
text_model = load_model("ai_models/text_lstm.h5")
tokenizer = joblib.load("ai_models/tokenizer.pkl")

# Load CNN for image classification
image_model = load_model("ai_models/image_cnn.h5")


def categorize_image(image_file):
    img = cv2.imdecode(np.frombuffer(image_file.read(), np.uint8), cv2.IMREAD_COLOR)
    img = cv2.resize(img, (128,128)) / 255.0
    img = np.expand_dims(img, axis=0)
    prediction = image_model.predict(img)
    labels = ["road", "water", "electricity", "garbage", "other"]
    return labels[prediction.argmax()]
