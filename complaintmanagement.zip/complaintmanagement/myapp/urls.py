"""complaintmanagement URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home 
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from myapp import views

urlpatterns = [

    path('login_get/',views.login_get),
    path('login_post/',views.login_post),
    path('home/',views.home),

    path('adminhome_get/',views.adminhome_get),
    path('adminchangepassword_get/',views.adminchangepassword_get),
    path('adminadddepartment_get/',views.adminadddepartment_get),
    path('adminadddepartment_post/',views.adminadddepartment_post),
    path('adminviewdepartment_get/',views.adminviewdepartment_get),
    path('admineditdepartment_get/',views.admineditdepartment_get),
    path('edit/<id>/',views.admineditdepartment_get),
    path('admineditdepartment_post/<id>/',views.admineditdepartment_post),
    path('delete/<id>/',views.admindeletedepartment_post),
    path('adminviewuser_get/',views.adminviewuser_get),
    path('adminviewfeedback_get/',views.adminviewfeedback_get),
    path('adminviewcomplaint_get/',views.adminviewcomplaint_get),
    path('departmentviewprofile_get/',views.departmentviewprofile_get),
    path('departmenthome_get/',views.departmenthome_get),
    path('adminchangepassword_post/',views.adminchangepassword_post),
    path('departmentviewcomplaint_get/',views.departmentviewcomplaint_get),
    path('complaintprogress_post/<id>/',views.complaintprogress_post),
    path('complaintresolved_post/<id>/',views.complaintresolved_post),
    path('adminviewmorecomplaint_post/<id>/',views.adminviewmorecomplaint_post),
    path('departmentchangepassword_get/',views.departmentchangepassword_get),
    path('departmentchangepassword_post/',views.departmentchangepassword_post),
    path('take_action_view/<id>/',views.take_action_view),
    path('createaction_get/<id>/',views.createaction_get),
    path('createaction_post/<id>/',views.createaction_post),
    path('userlogin/',views.userlogin),
    path('user_reg/',views.user_reg),
    path('view_profile/',views.view_profile),
    path('update_user_profile/',views.update_user_profile),
    path('sendcomplaint_post/',views.sendcomplaint_post),
    path('view_complaints/',views.view_complaints),
    path('changepassword_post/',views.changepassword_post),
    path('appreview_post/',views.appreview_post),
    path('appreview_post/',views.appreview_post),
    path('get_reviews/',views.get_reviews),
    path('view_actions/',views.view_actions),
    path('android_forget_password_post/',views.android_forget_password_post)
]
