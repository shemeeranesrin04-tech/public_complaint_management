import random
import smtplib
from datetime import datetime, time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from django.contrib.auth import authenticate, login
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth.models import User, Group
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect

# Create your views here.
from myapp.models import Department, Registration, Appreview, Complaint ,Action




def home(request):
    return render(request,'adminindex.html')


def login_get(request):
    return render(request,'login.html')
def login_post(request):
    a=request.POST['email']
    b=request.POST['pwd']
    try:
        l = authenticate(request,username=a,password=b)
        login(request, l)
        print("pppppppppppp",l)
        if l.groups.filter(name='admin').exists():
            return HttpResponse("<script>alert('Login is successful');window.location='/myapp/adminhome_get/';</script>")
        elif l.groups.filter(name='department').exists():
            r = Department.objects.get(AUTH_USER_id=l.id)
            request.session['did'] = r.id
            return HttpResponse(
                    "<script>alert('Login is successful');window.location='/myapp/departmenthome_get/';</script>")
        else:
            return HttpResponse(
                "<script>alert('Checkingggggg');window.location='/myapp/login_get/';</script>")

    except:
        return HttpResponse("<script>alert('Invalid username & Password');window.location='/myapp/login_get/';</script>")


def adminhome_get(request):
    return render(request,'adminhome.html')
def adminchangepassword_get(request):
    return render(request,'adminchangepassword.html')
def adminchangepassword_post(request):
    if request.method == "POST":
        current_password = request.POST["current_password"]
        new_password = request.POST["new_password"]
        confirm_password = request.POST["confirm_password"]
        user = request.user
        if not check_password(current_password, user.password):
            return HttpResponse("<script>alert('current password is not correct....!');window.location='/myapp/adminchangepassword_get/'</script>")

        user.set_password(new_password)
        user.save()

        return HttpResponse("<script>alert('Successfully changes....!');window.location='/myapp/login_get/'</script>")


def adminadddepartment_get(request):
    return render(request,'adminadddepartment.html')

def adminadddepartment_post(request):

    # Get form data
    a = request.POST['name']
    b = request.POST['description']
    c = request.POST['email']
    d = request.POST['phone']

    # Generate random password
    e = str(random.randint(1000, 9999))

    # Create user and assign to department group
    user = User.objects.create(username=c, password=make_password(e))
    user.groups.add(Group.objects.get(name='department'))
    user.save()

    # Create Department
    dobj = Department()
    dobj.dname = a
    dobj.description = b
    dobj.email = c
    dobj.phone = d
    dobj.AUTH_USER = user
    dobj.save()

    # Send password via email
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login("leagaladvisorteam@gmail.com", "eugnxtyylwtqwlav")  # App Password
    to = c
    subject = "Your Department Account Password"
    body = f"Hello {a},\n\nYour account has been created.\nUsername: {c}\nPassword: {e}\n\nPlease change your password after logging in."
    msg = f"Subject: {subject}\n\n{body}"
    server.sendmail("leagaladvisorteam@gmail.com", to, msg)
    server.quit()

    return HttpResponse("<script>alert('New Department saved and password sent via email');window.location='/myapp/adminadddepartment_get/';</script>")


def adminviewdepartment_get(request):
    o=Department.objects.all()
    return render(request,'adminviewdepartments.html',{'o':o})
def admineditdepartment_get(request,id):
    z=Department.objects.get(id=id)
    return render(request,'admineditdepartment.html',{'z':z})
def admineditdepartment_post(request,id):
    z = Department.objects.get(id=id)
    z.dname=request.POST['name']
    z.description=request.POST['description']
    z.email=request.POST['email']
    z.phone=request.POST['phone']
    z.save()
    return HttpResponse("<script>alert('Department edited');window.location='/myapp/adminviewdepartment_get/';</script>")
def admindeletedepartment_post(request,id):
    d=Department.objects.get(id=id)
    d.delete()
    return HttpResponse( "<script>alert('Edited');window.location='/myapp/adminviewdepartment_get/';</script>")
def adminviewuser_get(request):
    o=Registration.objects.all()
    return render(request,'adminviewuser.html',{"o":o})

def adminviewfeedback_get(request):
    o=Appreview.objects.all()
    return render(request,'adminviewfeedback.html',{'o':o})
def adminviewcomplaint_get(request):
    o=Complaint.objects.all()
    return render(request,'adminviewcomplaints.html',{'o':o})
def adminviewmorecomplaint_post(request,id):
    o=Complaint.objects.get(id=id)
    z = Action.objects.filter(COMPLAINT=o).order_by('date')
    return render(request,'adminviewmorecomplaint.html',{'i':o,"z":z})
def departmentviewprofile_get(request):
    o=Department.objects.get(id=request.session['did'])
    return render(request,'departmentviewprofile.html',{'i':o})
def departmentchangepassword_get(request):
    return render(request,'departmentchangepassword.html')
def departmentchangepassword_post(request):
        if request.method == "POST":
            current_password = request.POST["current_password"]
            new_password = request.POST["new_password"]
            confirm_password = request.POST["confirm_password"]
            user = request.user
            if not check_password(current_password, user.password):
                return HttpResponse(
                    "<script>alert('current password is not correct....!');window.location='/myapp/adminchangepassword_get/'</script>")

            user.set_password(new_password)
            user.save()

            return HttpResponse(
                "<script>alert('Successfully changes....!');window.location='/myapp/login_get/'</script>")


def departmenthome_get(request):
    return render(request,'departmenthome.html')
def departmentviewcomplaint_get(request):
    dept = Department.objects.get(id=request.session['did'])
    complaints = Complaint.objects.filter(DEPARTMENT=dept).select_related("REGISTRATION")

    return render(request, 'departmentviewcomplaint.html', {'o': complaints})

def complaintprogress_post(request,id):
    c=Complaint.objects.get(id=id)
    c.status='In Progress'
    c.save()
    return HttpResponse("<script>alert('Complaint in progress');window.location='/myapp/departmentviewcomplaint_get/';</script>")
def complaintresolved_post(request,id):
    c=Complaint.objects.get(id=id)
    c.status='Resolved'
    c.save()
    return HttpResponse("<script>alert('Complaint Resolved');window.location='/myapp/departmentviewcomplaint_get/';</script>")
def createaction_get(request, id):
    complaint_obj = Complaint.objects.get(id=id)
    return render(request, 'departmentcreateaction.html', {'i': complaint_obj})

def createaction_post(request,id):
    complaint_obj = Complaint.objects.get(id=id)
    a=request.POST['action']
    b=datetime.now()
    dobj=Action()
    dobj.description=a
    dobj.date=b
    dobj.COMPLAINT = complaint_obj
    dobj.save()
    return redirect('/myapp/adminviewmorecomplaint_post/{}/'.format(id))


def take_action_view(request, id):
    o = Complaint.objects.get(id=id)              # Get the complaint
    actions = Action.objects.filter(COMPLAINT=o).order_by('date') # Get all actions for this complaint

    return render(request, 'departmentviewtakeaction.html', {'i': o, 'actions': actions})









def userlogin(request):
    email = request.POST.get('Username')
    pwd = request.POST.get('Password')
    print(email, pwd)

    user = authenticate(request, username=email, password=pwd)
    if not user:
        # Return 'status' key so Flutter can read it safely
        return JsonResponse({'status': 'invalid', 'message': 'Invalid email or password'})

    reg = Registration.objects.get(AUTH_USER=user)
    image_url = f"{reg.image}" if reg.image else ""
    print("User image:", image_url)

    login(request, user)

    return JsonResponse({
        'status': 'ok',
        'lid': str(user.id),
        'image_url': image_url
    })



def user_reg(request):
    a=request.POST['uname']
    b=request.POST['uemail']
    c=request.POST['uphoneno']
    d=request.POST['upassword']
    e=request.POST['gender']
    f=request.POST['place']
    g=request.POST['pincode']
    h=request.POST['state']
    i=request.POST['city']
    j=request.FILES['photo']
    print("myphotoooooooooooo",j)
    fs=FileSystemStorage()
    date=datetime.now().strftime("%Y%m%d%H%M%S") + ".jpg"
    print("pppppppppp",date)
    fs.save(date,j)

    path=fs.url(date)
    print('pathhhhhhhhhhhhhh',path)
    l = User.objects.create(username=b, password=str(make_password(d)))
    l.groups.add(Group.objects.get(name='user'))
    l.save()
    dobj=Registration()
    dobj.name=a
    dobj.email=b
    dobj.phone=c
    dobj.gender=e
    dobj.place=f
    dobj.pincode=g
    dobj.state=h
    dobj.city=i
    dobj.image=path
    dobj.AUTH_USER=l
    dobj.save()
    return JsonResponse({"status":"ok"})

def view_profile(request):
    lid = int(request.POST['lid'])
    user = User.objects.get(id=lid)
    res = Registration.objects.get(AUTH_USER=user)


    data = {
        "id": res.id,
        "name": res.name,
        "gender": res.gender,
        "email": res.email,
        "phone": res.phone,
        "place": res.place,
        "pincode": res.pincode,
        "state": res.state,
        "city": res.city,
        "photo": res.image.url if res.image else "",
    }


    return JsonResponse({"status": "ok", "data": data})



def update_user_profile(request):
    if request.method == "POST":
        lid = request.POST.get("lid")
        try:
            user = User.objects.get(id=lid)
            reg = Registration.objects.get(AUTH_USER=user)

            # Update fields from POST (keep old value if not provided)
            reg.name = request.POST["name"]
            reg.email = request.POST["email"]
            reg.phone = request.POST["phone"]
            reg.gender = request.POST["gender"]
            reg.place = request.POST["place"]
            reg.pincode = request.POST["pincode"]
            reg.state = request.POST["state"]
            reg.city = request.POST["city"]

            # Handle photo upload
            if 'photo' in request.FILES:
                reg.image = request.FILES['photo']

            reg.save()

            # Also update username in User model
            user.username = reg.email
            user.save()

            return JsonResponse({"status": "ok"})

        except User.DoesNotExist:
            return JsonResponse({"status": "user not found"})
        except Registration.DoesNotExist:
            return JsonResponse({"status": "registration not found"})

    return JsonResponse({"status": "failed"})




#


def view_complaints(request):
    if request.method == "POST":
        lid = request.POST.get("lid")

        if not lid:
            return JsonResponse({"status": "failed", "message": "Login ID required", "data": []})

        try:

            reg = Registration.objects.get(AUTH_USER_id=lid)


            complaints = Complaint.objects.filter(REGISTRATION=reg).order_by('-date')

            data_list = []
            for c in complaints:

                if c.image and c.image.name:
                    image_url = request.build_absolute_uri(c.image.url)
                else:
                    image_url = None

                data_list.append({
                    "id": c.id,
                    "complaint": c.complaint,
                    "date": c.date,
                    "status": c.status,
                    "category": c.category,
                    "priority": c.priority,
                    "place_name": c.place_name,
                    "department_name": c.DEPARTMENT.dname if c.DEPARTMENT else "",
                    "latitude": c.latitude,
                    "longitude": c.longitude,
                    "image": image_url
                })

            return JsonResponse({"status": "ok", "data": data_list})

        except Registration.DoesNotExist:
            return JsonResponse({"status": "failed", "message": "Registration not found", "data": []})
        except Exception as e:
            return JsonResponse({"status": "failed", "message": f"Error: {str(e)}", "data": []})

    return JsonResponse({"status": "failed", "message": "Invalid request method", "data": []})








def changepassword_post(request):
    if request.method == "POST":
        lid = request.POST.get("lid")
        current_password = request.POST.get("current_password")
        new_password = request.POST.get("new_password")
        confirm_password = request.POST.get("confirm_password")

        user = User.objects.get(id=lid)

        if not check_password(current_password, user.password):
            return JsonResponse({"status": "error", "message": "Current password is incorrect"})

        if new_password != confirm_password:
            return JsonResponse({"status": "error", "message": "Passwords do not match"})

        user.set_password(new_password)
        user.save()

        return JsonResponse({"status": "ok", "message": "Password changed successfully"})

    return JsonResponse({"status": "error", "message": "Invalid request method"})


def appreview_post(request):
    if request.method == "POST":
        lid = request.POST["lid"]
        review_text = request.POST["review"]
        rating = request.POST["rating"]


        if not lid or not review_text or not rating:
            return JsonResponse({"status": "error", "message": "Missing required fields"})


        user = Registration.objects.get(AUTH_USER__id=lid)


        Appreview.objects.create(
            REGISTRATION=user,
            review=review_text,
            rating=int(rating),
            date=datetime.now()
        )


        return JsonResponse({"status": "ok", "message": "Review submitted successfully"})

    return JsonResponse({"status": "error", "message": "Invalid request method"})




def get_reviews(request):
    reviews = Appreview.objects.select_related('REGISTRATION')
    data = []

    for r in reviews:
        data.append({
            'review': r.review,
            'rating': r.rating,
            'user_name': r.REGISTRATION.name,
        })

    return JsonResponse({'status': 'ok', 'data': data})





def view_actions(request):
    if request.method == 'POST':
        complaint_id = request.POST.get('complaint_id')
        actions = Action.objects.filter(COMPLAINT_id=complaint_id)
        data = []
        for action in actions:
            data.append({
                'date': action.date,
                'description': action.description
            })
        return JsonResponse({'status': 'ok', 'data': data})
    return JsonResponse({'status': 'error', 'data': []})





def android_forget_password_post(request):
    if request.method == "POST":
        email = request.POST.get('email', '').strip()
        if not email:
            return JsonResponse({'status': 'error', 'message': 'Email is required'})

        try:

            user = User.objects.get(username=email)


            new_pass = str(random.randint(1000, 9999))
            user.password = make_password(new_pass)
            user.save()


            smtp_server = "smtp.gmail.com"
            smtp_port = 587
            sender_email = "trainingstarted@gmail.com"
            app_password = "nlxasujxgazlbmgz"
            subject = "Your New Password"
            body = f"Your new password is: {new_pass}"
            message = MIMEMultipart()
            message["From"] = sender_email
            message["To"] = email
            message["Subject"] = subject
            message.attach(MIMEText(body, "plain"))


            server = smtplib.SMTP(smtp_server, smtp_port)
            server.starttls()
            server.login(sender_email, app_password)
            server.send_message(message)
            server.quit()

            return JsonResponse({'status': 'ok', 'message': 'Password sent to your email'})

        except User.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'Email not found'})

        except Exception as e:
            return JsonResponse({'status': 'error', 'message': f'Email send error: {str(e)}'})

    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})


# import os
# import json
# from django.shortcuts import HttpResponse
# from datetime import datetime
# from .models import Complaint, Department, Registration
# from .text_prediction import full_prediction  # your model file
#
# def sendcomplaint_post(request):
#     if request.method != "POST":
#         return HttpResponse(
#             json.dumps({'status': 'error', 'message': 'Only POST requests allowed.'}),
#             content_type="application/json", status=405
#         )
#
#     try:
#         # ---------------- Extract fields ----------------
#         lid = request.POST.get('lid')
#         complaint_text = request.POST.get('complaint')
#         place_name = request.POST.get('place_name')
#         latitude = request.POST.get('latitude')
#         longitude = request.POST.get('longitude')
#         image = request.FILES.get('image')
#
#         print("Received lid:", lid)
#         print("Complaint text:", complaint_text)
#
#         # ---------------- Validate user ----------------
#         try:
#             registration = Registration.objects.get(AUTH_USER=lid)
#         except Registration.DoesNotExist:
#             return HttpResponse(
#                 json.dumps({'status': 'error', 'message': 'User not found'}),
#                 content_type="application/json", status=400
#             )
#
#         # ---------------- Save image temporarily for prediction ----------------
#         image_path = None
#         if image:
#             tmp_dir = "media/temp/"
#             os.makedirs(tmp_dir, exist_ok=True)
#             tmp_path = os.path.join(tmp_dir, image.name)
#             with open(tmp_path, "wb+") as f:
#                 for chunk in image.chunks():
#                     f.write(chunk)
#             image_path = tmp_path
#
#         # ---------------- Run prediction ----------------
#         result = full_prediction(complaint_text, image_path)
#         predicted_department_name = result['predicted_department']
#         priority = result['priority']
#         image_description = result.get('image_description')
#
#         print("Predicted Department:", predicted_department_name)
#         print("Priority:", priority)
#
#         # ---------------- Get or create department ----------------
#         department, created = Department.objects.get_or_create(
#             dname=predicted_department_name,
#             defaults={'AUTH_USER': registration.AUTH_USER, 'description': '', 'email': '', 'phone': ''}
#         )
#
#         # ---------------- Save complaint ----------------
#         comp = Complaint.objects.create(
#             REGISTRATION=registration,
#             DEPARTMENT=department,
#             date=str(datetime.now()),
#             complaint=complaint_text,
#             category=predicted_department_name,
#             priority=priority,
#             status="Pending",
#             place_name=place_name,
#             image=image,
#             latitude=latitude,
#             longitude=longitude
#         )
#
#         # ---------------- Cleanup temp image ----------------
#         if image_path and os.path.exists(image_path):
#             os.remove(image_path)
#
#         # ---------------- Return response ----------------
#         return HttpResponse(
#             json.dumps({
#                 'status': 'ok',
#                 'complaint_id': comp.id,
#                 'predicted_department': predicted_department_name,
#                 'priority': priority,
#                 'image_description': image_description
#             }),
#             content_type="application/json"
#         )
#
#     except Exception as e:
#         print("Error in sendcomplaint_post:", e)
#         return HttpResponse(
#             json.dumps({'status': 'error', 'message': str(e)}),
#             content_type="application/json", status=500
#         )
# from django.http import JsonResponse
# from django.utils import timezone
# from datetime import datetime
# from .text_prediction import full_prediction
# from .models import Complaint, Department, Registration
#
# def sendcomplaint_post(request):
#     if request.method == "POST":
#         lid = request.POST.get("lid")
#         complaint_text = request.POST.get("complaint")
#         image = request.FILES.get("image")
#         place_name = request.POST.get("place_name")
#         latitude = request.POST.get("latitude")
#         longitude = request.POST.get("longitude")
#
#         # AI prediction
#         result = full_prediction(complaint_text)
#         predicted_dept_name = result["predicted_department"]
#         priority = result["priority"]
#
#         # Validate registration
#         try:
#             registration = Registration.objects.get(AUTH_USER=lid)
#         except Registration.DoesNotExist:
#             return JsonResponse({"status": "error", "message": "User not found"}, status=400)
#
#         # Validate department
#         try:
#             department = Department.objects.get(dname=predicted_dept_name)
#         except Department.DoesNotExist:
#             return JsonResponse({"status": "error", "message": "Department not found"}, status=400)
#
#         # Create complaint
#         complaint = Complaint.objects.create(
#             REGISTRATION=registration,
#             DEPARTMENT=department,
#             date=str(datetime.now()),  # make sure to import datetime
#             complaint=complaint_text,
#             category=predicted_dept_name,
#             priority=priority,
#             status="Pending",
#             place_name=place_name or "-",
#             image=image if image else None,
#             latitude=latitude or "-",
#             longitude=longitude or "-"
#         )
#
#         # Optional: confirm creation
#         if complaint.id:
#             return JsonResponse({"status": "ok", "complaint_id": complaint.id})
#         else:
#             return JsonResponse({"status": "error", "message": "Failed to create complaint"}, status=500)
from django.http import JsonResponse
from datetime import datetime
from .text_prediction import full_prediction
from .models import Complaint, Department, Registration

def sendcomplaint_post(request):
    if request.method == "POST":
        lid = request.POST.get("lid")
        complaint_text = request.POST.get("complaint")
        image = request.FILES.get("image")
        place_name = request.POST.get("place_name")
        latitude = request.POST.get("latitude")
        longitude = request.POST.get("longitude")

        # Run AI prediction (pass image if uploaded)
        image_path = image.temporary_file_path() if image else None
        result = full_prediction(complaint_text, image_path)

        predicted_dept_name = result["predicted_department"]
        priority = result["priority"]

        # Validate registration
        try:
            registration = Registration.objects.get(AUTH_USER=lid)
        except Registration.DoesNotExist:
            return JsonResponse({"status": "error", "message": "User not found"}, status=400)

        # Validate department
        try:
            department = Department.objects.get(dname=predicted_dept_name)
        except Department.DoesNotExist:
            return JsonResponse({"status": "error", "message": "Department not found"}, status=400)

        # Save complaint
        complaint = Complaint.objects.create(
            REGISTRATION=registration,
            DEPARTMENT=department,
            date=str(datetime.now()),
            complaint=complaint_text,
            category=predicted_dept_name,
            priority=priority,
            status="Pending",
            place_name=place_name or "-",
            image=image if image else None,
            latitude=latitude or "-",
            longitude=longitude or "-"
        )

        return JsonResponse({"status": "ok", "complaint_id": complaint.id})
